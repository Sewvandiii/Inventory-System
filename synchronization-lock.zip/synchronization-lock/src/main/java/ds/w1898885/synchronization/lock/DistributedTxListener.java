package ds.w1898885.synchronization.lock;

public interface DistributedTxListener {
    void onGlobalCommit();
    void onGlobalAbort();
}