package ds.w1898885.communication.client;

import ds.w1898885.communication.grpc.generated.SetInventoryStockRequest;
import ds.w1898885.communication.grpc.generated.SetInventoryStockResponse;
import ds.w1898885.communication.grpc.generated.SetInventoryStockServiceGrpc;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;

import java.util.Scanner;

public class SetInventoryStockServiceClient {

    private ManagedChannel channel = null;
    SetInventoryStockServiceGrpc.SetInventoryStockServiceBlockingStub clientStub = null;
    String host = null;
    int port = -1;

    public SetInventoryStockServiceClient (String host, int port) {
        this.host = host;
        this.port = port;
    }

    public void initializeConnection () {
        System.out.println("Initializing Connecting to server at " + host + ":" +
                port);
        channel = ManagedChannelBuilder.forAddress("localhost", port)
                .usePlaintext()
                .build();
        clientStub = SetInventoryStockServiceGrpc.newBlockingStub(channel);
    }
    public void closeConnection() {
        channel.shutdown();
    }

    public void processUserRequests() throws InterruptedException {
        while (true) {
            Scanner userInput = new Scanner(System.in);
            System.out.println("\nEnter item ID, Quantity :");
            String input[] = userInput.nextLine().trim().split(",");
            String itemId = input[0];
            int amount = Integer.parseInt(input[1]);
            String person = "Clerk";
            System.out.println("Requesting server to set the item stock to " + amount + " for " + itemId.toString());
            System.out.println("Person is a" + person);
            SetInventoryStockRequest request = SetInventoryStockRequest
                    .newBuilder()
                    .setItemId(itemId)
                    .setValue(amount)
                    .setIsSentByPrimary(false)
                    .setPerson(person)
                    .build();
            SetInventoryStockResponse response = clientStub.setInventoryStock(request);
            System.out.printf("Transaction Status " + (response.getStatus() ? "Sucessful" : "Failed"));
            Thread.sleep(1000);
        }
    }
}
