package ds.w1898885.communication.client;

public class MainClass {
    public static void main(String[] args) throws InterruptedException {
        String host = args[0];
        int port = Integer.parseInt(args[1].trim());
        String operation = args[2];

        if (args.length != 3) {
            System.out.println("Usage CheckInventoryStockServiceClient <host> <port> <s(et)|c(heck)");
            System.exit(1);
        }

        if ("s".equals(operation)) {
            SetInventoryStockServiceClient client = new SetInventoryStockServiceClient(host, port);
            client.initializeConnection();
            client.processUserRequests();
            client.closeConnection();
        } else {
            CheckInventoryStockServiceClient client = new CheckInventoryStockServiceClient(host, port);
            client.initializeConnection();
            client.processUserRequests();
            client.closeConnection();
        }
    }
}
