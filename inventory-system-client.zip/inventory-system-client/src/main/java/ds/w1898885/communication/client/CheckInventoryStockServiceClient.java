package ds.w1898885.communication.client;

import ds.w1898885.communication.grpc.generated.CheckInventoryStockRequest;
import ds.w1898885.communication.grpc.generated.CheckInventoryStockResponse;
import ds.w1898885.communication.grpc.generated.InventoryStockServiceGrpc;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;

import java.util.Scanner;

public class CheckInventoryStockServiceClient {
    private ManagedChannel channel = null;
    InventoryStockServiceGrpc.InventoryStockServiceBlockingStub clientStub = null;
    String host = null;
    int port = -1;

    public CheckInventoryStockServiceClient (String host, int port) {
        this.host = host;
        this.port = port;
    }

    public void initializeConnection () {
        System.out.println("Initializing Connecting to server at " + host + ":" +
                port);
        channel = ManagedChannelBuilder.forAddress("localhost", port)
                .usePlaintext()
                .build();
        clientStub = InventoryStockServiceGrpc.newBlockingStub(channel);
    }
    public void closeConnection() {
        channel.shutdown();
    }

    public void processUserRequests() throws InterruptedException {
        while (true) {
            Scanner userInput = new Scanner(System.in);
            System.out.println("\nEnter item ID to check the stock :");
            String itemId = userInput.nextLine().trim();
            System.out.println("Requesting server to check the item stock for " + itemId.toString());
            CheckInventoryStockRequest request = CheckInventoryStockRequest
                    .newBuilder()
                    .setItemId(itemId)
                    .build();
            CheckInventoryStockResponse response = clientStub.checkInventoryStock(request);
            System.out.printf("My item stock is " + response.getInventoryStock());
            Thread.sleep(1000);
        }
    }
}
