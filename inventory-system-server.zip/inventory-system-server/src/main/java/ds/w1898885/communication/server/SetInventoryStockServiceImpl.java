package ds.w1898885.communication.server;

import ds.w1898885.communication.grpc.generated.SetInventoryStockRequest;
import ds.w1898885.communication.grpc.generated.SetInventoryStockResponse;
import ds.w1898885.communication.grpc.generated.SetInventoryStockServiceGrpc;
import ds.w1898885.synchronization.lock.DistributedTxCoordinator;
import ds.w1898885.synchronization.lock.DistributedTxListener;
import ds.w1898885.synchronization.lock.DistributedTxParticipant;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;

import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.apache.zookeeper.KeeperException;

import java.io.IOException;
import java.util.List;
import java.util.UUID;

public class SetInventoryStockServiceImpl extends SetInventoryStockServiceGrpc.SetInventoryStockServiceImplBase implements DistributedTxListener {
    private ManagedChannel channel = null;
    SetInventoryStockServiceGrpc.SetInventoryStockServiceBlockingStub clientStub = null;
    private InventoryServer server;

    private boolean transactionStatus = false;
    private Pair<String, Integer> tempDataHolder;

    public SetInventoryStockServiceImpl(InventoryServer server){
        this.server = server;
    }

    public void startDistributedTx(String itemId, int value) {
        try {
            server.getTransaction().start(itemId, String.valueOf(UUID.randomUUID()));
            ImmutablePair<String, Integer> pair = new ImmutablePair<>(itemId, value);
            tempDataHolder = Pair.of(itemId, value);
            //tempDataHolder = new Pair<>(itemId, value);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    @Override
    public void onGlobalCommit() {
        updateInventoryStock();
    }

    @Override
    public void setInventoryStock(ds.w1898885.communication.grpc.generated.SetInventoryStockRequest request,
               io.grpc.stub.StreamObserver<ds.w1898885.communication.grpc.generated.SetInventoryStockResponse> responseObserver) {
        String itemId = request.getItemId();
        int value = request.getValue();
        String person = request.getPerson();
        int OldlStock= server.getItemInventoryStock(itemId);
        value = OldlStock + value;

        if (server.isLeader()){
            // Act as primary
            try {
                System.out.println("Updating item stock as Primary");
                startDistributedTx(itemId, value);
                updateSecondaryServers(itemId, value);
                System.out.println("going to perform");
                if (value > 0){
                    ((DistributedTxCoordinator)server.getTransaction()).perform();
                } else {
                    ((DistributedTxCoordinator)server.getTransaction()).sendGlobalAbort();
                }
            } catch (Exception e) { System.out.println("Error while updating the item stock" + e.getMessage());
                    e.printStackTrace();
            }
        } else {
            // Act As Secondary
            if (request.getIsSentByPrimary()) {
                System.out.println("Updating item stock on secondary, on Primary's command");
                startDistributedTx(itemId, value);
                if (value != 0) {
                    ((DistributedTxParticipant)server.getTransaction()).voteCommit();
                } else {
                    ((DistributedTxParticipant)server.getTransaction()).voteAbort();
                }
            } else {
                SetInventoryStockResponse response = callPrimary(itemId, value);
                if (response.getStatus()) {
                    transactionStatus = true;
                }
            }
        }

        SetInventoryStockResponse response = SetInventoryStockResponse
                .newBuilder()
                .setStatus(transactionStatus)
                .build();

        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    private void updateInventoryStock() {
        if (tempDataHolder != null) {
            String itemId = tempDataHolder.getKey();
            int value = tempDataHolder.getValue();
            server.setItemInventoryStock(itemId, value);
            System.out.println("Account " + itemId + " updated to value " + value + " committed");
            tempDataHolder = null;
        }
    }

    private SetInventoryStockResponse callServer(String itemId, int value, boolean isSentByPrimary, String IPAddress, int port) {
        System.out.println("Call Server " + IPAddress + ":" + port);

        channel = ManagedChannelBuilder.forAddress(IPAddress, port)
                .usePlaintext()
                .build();
        clientStub = SetInventoryStockServiceGrpc.newBlockingStub(channel);

        SetInventoryStockRequest request = SetInventoryStockRequest
                .newBuilder()
                .setItemId(itemId)
                .setValue(value)
                .setIsSentByPrimary(isSentByPrimary)
                .build();
        SetInventoryStockResponse response = clientStub.setInventoryStock(request);
        return response;
    }

    private SetInventoryStockResponse callPrimary(String itemId, int value) {
        System.out.println("Calling Primary server");
        String[] currentLeaderData = server.getCurrentLeaderData();
        String IPAddress = currentLeaderData[0];
        int port = Integer.parseInt(currentLeaderData[1]);
        return callServer(itemId, value, false, IPAddress, port);
    }

    private void updateSecondaryServers(String itemId, int value) throws KeeperException, InterruptedException {
        System.out.println("Updating secondary servers");
        List<String[]> othersData = server.getOthersData();
        for (String[] data : othersData) {
            String IPAddress = data[0];
            int port = Integer.parseInt(data[1]);
            callServer(itemId, value, true, IPAddress,port);
        }
    }


    @Override
    public void onGlobalAbort() {
        tempDataHolder = null; System.out.println("Transaction Aborted by the Coordinator");
    }
}