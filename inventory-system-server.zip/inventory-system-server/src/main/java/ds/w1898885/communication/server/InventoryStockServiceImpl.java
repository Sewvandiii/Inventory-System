package ds.w1898885.communication.server;

import ds.w1898885.communication.grpc.generated.CheckInventoryStockResponse;
import ds.w1898885.communication.grpc.generated.InventoryStockServiceGrpc;

import java.util.Random;

public class InventoryStockServiceImpl extends InventoryStockServiceGrpc.InventoryStockServiceImplBase {

    private InventoryServer server;

    public InventoryStockServiceImpl(InventoryServer server){
        this.server = server;
    }
    @Override
    public void checkInventoryStock(ds.w1898885.communication.grpc.generated.CheckInventoryStockRequest request,
                                    io.grpc.stub.StreamObserver<ds.w1898885.communication.grpc.generated.CheckInventoryStockResponse> responseObserver) {
        String itemId = request.getItemId();
        System.out.println("Request received..");
        Integer inventoryStock= getItemInventoryStock(itemId);
        CheckInventoryStockResponse response = CheckInventoryStockResponse
                .newBuilder()
                .setInventoryStock(inventoryStock)
                .build();
        System.out.println("Responding stock for item " + itemId + " is " + inventoryStock);
        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    private int getItemInventoryStock(String itemId) {
        return server.getItemInventoryStock(itemId);
    }
}
